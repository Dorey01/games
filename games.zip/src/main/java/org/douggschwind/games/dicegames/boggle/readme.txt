boggle.xmi houses the Umbrello version of the Class Diagram for Boggle.
boggle.png houses a screen capture of the Umbrello version of the Class
           Diagram for Boggle.
